import { Link } from 'react-router-dom'
import { site } from '../../data/content'

// Gradient square with the initials + brand name and role, like the reference's "DV  DevPort".
export default function Logo({ onClick }) {
  return (
    <Link
      to="/"
      onClick={onClick}
      aria-label={`${site.brand}, home`}
      className="inline-flex min-h-11 items-center gap-3"
    >
      <span
        aria-hidden="true"
        className="grad-bg flex h-10 w-10 items-center justify-center rounded-xl text-sm font-bold tracking-tight text-white shadow-lg shadow-brand-violet/30"
      >
        {site.initials}
      </span>
      <span className="leading-tight">
        <span className="block text-base font-bold text-fg">{site.brand}</span>
        <span className="hidden text-xs text-muted sm:block">{site.title}</span>
      </span>
    </Link>
  )
}
